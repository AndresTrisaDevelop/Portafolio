from fastapi import APIRouter, HTTPException, status
from typing import List
from ..schemas.vendor import Vendor, VendorUpdate

router = APIRouter(
    prefix="/vendors",
    tags=["Vendors"],
)

@router.post("/", response_model=Vendor, status_code=status.HTTP_201_CREATED, summary="Create Vendor", description="Registers a new vendor in the system with their contact and identification details.")
async def create_vendor(vendor: Vendor):
    """
    Create a new Vendor.
    """
    print(f"Creating Vendor: {vendor.name}")
    return vendor

@router.get("/", response_model=List[Vendor], summary="Get All Vendors", description="Retrieves a comprehensive list of all registered vendors.")
async def get_all_vendors():
    """
    Retrieve all Vendors.
    """
    return []

@router.get("/{vendor_id}", response_model=Vendor, summary="Get Vendor by ID", description="Fetches the detailed information for a single vendor using their unique identifier.")
async def get_vendor(vendor_id: str):
    """
    Retrieve a specific Vendor by its ID.
    """
    raise HTTPException(status_code=404, detail=f"Vendor {vendor_id} not found")

@router.patch("/{vendor_id}", response_model=Vendor, summary="Update Vendor", description="Modifies the existing details of a vendor identified by their unique ID.")
async def update_vendor(vendor_id: str, vendor_update: VendorUpdate):
    """
    Update a Vendor.
    """
    raise HTTPException(status_code=404, detail=f"Vendor {vendor_id} not found")

@router.delete("/{vendor_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete Vendor", description="Removes a vendor record from the system based on their unique identifier.")
async def delete_vendor(vendor_id: str):
    """
    Delete a Vendor.
    """
    print(f"Deleting Vendor: {vendor_id}")
    return