from fastapi import APIRouter, HTTPException, status
from typing import List
from ..schemas.catalog import CatalogItem, CatalogItemUpdate

router = APIRouter(
    prefix="/catalogs",
    tags=["Catalogs"],
)

@router.post("/", response_model=CatalogItem, status_code=status.HTTP_201_CREATED, summary="Create Catalog Item", description="Adds a new product item to the catalog, including its code, description, and pricing.")
async def create_catalog_item(item: CatalogItem):
    """
    Create a new item in the product catalog.
    """
    print(f"Creating Catalog Item: {item.catalogCode}")
    return item

@router.get("/", response_model=List[CatalogItem], summary="Get All Catalog Items", description="Retrieves a list of all items available in the product catalog.")
async def get_all_catalog_items():
    """
    Retrieve all items from the product catalog.
    """
    return []

@router.get("/{catalog_code}", response_model=CatalogItem, summary="Get Catalog Item by Code", description="Fetches the detailed information for a specific catalog item using its unique catalog code.")
async def get_catalog_item(catalog_code: str):
    """
    Retrieve a specific catalog item by its code.
    """
    raise HTTPException(status_code=404, detail=f"Catalog item {catalog_code} not found")

@router.patch("/{catalog_code}", response_model=CatalogItem, summary="Update Catalog Item", description="Modifies the details of an existing catalog item, such as description, price, or category.")
async def update_catalog_item(catalog_code: str, item_update: CatalogItemUpdate):
    """
    Update a catalog item's details.
    """
    raise HTTPException(status_code=404, detail=f"Catalog item {catalog_code} not found")

@router.delete("/{catalog_code}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete Catalog Item", description="Removes a product item from the catalog based on its unique catalog code.")
async def delete_catalog_item(catalog_code: str):
    """
    Delete a catalog item.
    """
    print(f"Deleting Catalog Item: {catalog_code}")
    return