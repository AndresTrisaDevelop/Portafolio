from fastapi import APIRouter, HTTPException, status
from typing import List
from ..schemas.tax_group import TaxGroup, TaxGroupUpdate

router = APIRouter(
    prefix="/config",
    tags=["Configuration"],
)

# --- Endpoints para Tax Groups ---

@router.post("/tax-groups", response_model=TaxGroup, status_code=status.HTTP_201_CREATED, summary="Create Tax Group", description="Adds a new tax group definition to the system, specifying its ID, name, and rate.")
async def create_tax_group(tax_group: TaxGroup):
    """
    Create a new Tax Group.
    """
    print(f"Creating Tax Group: {tax_group.name}")
    return tax_group

@router.get("/tax-groups", response_model=List[TaxGroup], summary="Get All Tax Groups", description="Retrieves a list of all defined tax groups.")
async def get_all_tax_groups():
    """
    Retrieve all Tax Groups.
    """
    return []

@router.get("/tax-groups/{tax_group_id}", response_model=TaxGroup, summary="Get Tax Group by ID", description="Fetches the details of a specific tax group using its unique ID.")
async def get_tax_group(tax_group_id: str):
    """
    Retrieve a specific Tax Group by its ID.
    """
    raise HTTPException(status_code=404, detail=f"Tax Group {tax_group_id} not found")

@router.patch("/tax-groups/{tax_group_id}", response_model=TaxGroup, summary="Update Tax Group", description="Modifies the name or rate for an existing tax group.")
async def update_tax_group(tax_group_id: str, tax_group_update: TaxGroupUpdate):
    """
    Update a Tax Group.
    """
    raise HTTPException(status_code=404, detail=f"Tax Group {tax_group_id} not found")

@router.delete("/tax-groups/{tax_group_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete Tax Group", description="Removes a tax group definition from the system based on its unique ID.")
async def delete_tax_group(tax_group_id: str):
    """
    Delete a Tax Group.
    """
    print(f"Deleting Tax Group: {tax_group_id}")
    return