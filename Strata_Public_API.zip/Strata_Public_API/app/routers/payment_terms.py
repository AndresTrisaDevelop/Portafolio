from fastapi import APIRouter, HTTPException, status
from typing import List
from ..schemas.payment_term import PaymentTerm, PaymentTermUpdate

router = APIRouter(
    prefix="/payment-terms",
    tags=["Payment Terms"],
)

@router.post("/", response_model=PaymentTerm, status_code=status.HTTP_201_CREATED, summary="Create Payment Term", description="Adds a new payment term definition to the system, specifying its ID, description, and due days.")
async def create_payment_term(payment_term: PaymentTerm):
    """
    Create a new Payment Term.
    """
    print(f"Creating Payment Term: {payment_term.description}")
    return payment_term

@router.get("/", response_model=List[PaymentTerm], summary="Get All Payment Terms", description="Retrieves a list of all defined payment terms.")
async def get_all_payment_terms():
    """
    Retrieve all Payment Terms.
    """
    return []

@router.get("/{term_id}", response_model=PaymentTerm, summary="Get Payment Term by ID", description="Fetches the details of a specific payment term using its unique ID.")
async def get_payment_term(term_id: str):
    """
    Retrieve a specific Payment Term by its ID.
    """
    raise HTTPException(status_code=404, detail=f"Payment Term {term_id} not found")

@router.patch("/{term_id}", response_model=PaymentTerm, summary="Update Payment Term", description="Modifies the description or due days for an existing payment term.")
async def update_payment_term(term_id: str, term_update: PaymentTermUpdate):
    """
    Update a Payment Term.
    """
    raise HTTPException(status_code=404, detail=f"Payment Term {term_id} not found")

@router.delete("/{term_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete Payment Term", description="Removes a payment term definition from the system based on its unique ID.")
async def delete_payment_term(term_id: str):
    """
    Delete a Payment Term.
    """
    print(f"Deleting Payment Term: {term_id}")
    return