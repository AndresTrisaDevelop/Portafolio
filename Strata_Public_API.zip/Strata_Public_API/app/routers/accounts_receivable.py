from fastapi import APIRouter, HTTPException, status
from typing import List
from ..schemas.customer_invoice import CustomerInvoice, CustomerInvoiceUpdate
from ..schemas.acknowledgment import Acknowledgement, AcknowledgementUpdate

router = APIRouter(
    prefix="/ar",
)

# --- Endpoints para Customer Invoices ---
@router.post("/customer-invoices", response_model=CustomerInvoice, status_code=status.HTTP_201_CREATED, summary="Create Customer Invoice", description="Generates and records a new invoice for a customer, detailing products/services and amounts due.", tags=["AR - Customer Invoices"])
async def create_customer_invoice(invoice: CustomerInvoice):
    """
    Create a new Customer Invoice.
    """
    # Lógica para guardar la factura de cliente
    print(f"Creating Invoice: {invoice.invoiceIdentifiers.invoiceNumber}")
    return invoice

@router.get("/customer-invoices", response_model=List[CustomerInvoice], summary="Get All Customer Invoices", description="Retrieves a list of all invoices issued to customers.", tags=["AR - Customer Invoices"])
async def get_all_customer_invoices():
    """
    Retrieve all Customer Invoices.
    """
    return []

@router.get("/customer-invoices/{invoice_number}", response_model=CustomerInvoice, summary="Get Customer Invoice by Number", description="Fetches the complete details of a specific customer invoice using its unique invoice number.", tags=["AR - Customer Invoices"])
async def get_customer_invoice(invoice_number: str):
    """
    Retrieve a specific Customer Invoice by its number.
    """
    raise HTTPException(status_code=404, detail=f"Invoice {invoice_number} not found")

@router.patch("/customer-invoices/{invoice_number}", response_model=CustomerInvoice, summary="Update Customer Invoice", description="Updates the information for an existing customer invoice, such as payment status or line item adjustments.", tags=["AR - Customer Invoices"])
async def update_customer_invoice(invoice_number: str, invoice_update: CustomerInvoiceUpdate):
    """
    Update a Customer Invoice.
    """
    raise HTTPException(status_code=404, detail=f"Invoice {invoice_number} not found")

@router.delete("/customer-invoices/{invoice_number}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete Customer Invoice", description="Cancels or removes a customer invoice from the system based on its unique invoice number.", tags=["AR - Customer Invoices"])
async def delete_customer_invoice(invoice_number: str):
    """
    Delete a Customer Invoice.
    """
    print(f"Deleting Invoice: {invoice_number}")
    return

# --- Endpoints para Acknowledgements ---

@router.post("/acknowledgements", response_model=Acknowledgement, status_code=status.HTTP_201_CREATED, summary="Create Acknowledgement", description="Records a new acknowledgement received from a vendor, confirming order details or shipping dates.", tags=["AR - Acknowledgements"])
async def create_acknowledgement(ack: Acknowledgement):
    """
    Create a new Acknowledgement.
    """
    # Lógica para crear un acknowledgement
    print(f"Creating Acknowledgement: {ack.ackInfo.acknowledgementNumber}")
    return ack

@router.get("/acknowledgements", response_model=List[Acknowledgement], summary="Get All Acknowledgements", description="Retrieves a list of all acknowledgements received from vendors.", tags=["AR - Acknowledgements"])
async def get_all_acknowledgements():
    """
    Retrieve all Acknowledgements.
    """
    # Lógica para obtener todos los acknowledgements de la base de datos
    return []

@router.get("/acknowledgements/{ack_number}", response_model=Acknowledgement, summary="Get Acknowledgement by Number", description="Fetches the detailed information for a specific acknowledgement using its unique acknowledgement number.", tags=["AR - Acknowledgements"])
async def get_acknowledgement(ack_number: str):
    """
    Retrieve a specific Acknowledgement by its number.
    """
    # Lógica para buscar un acknowledgement por su número
    raise HTTPException(status_code=404, detail=f"Acknowledgement {ack_number} not found")

@router.patch("/acknowledgements/{ack_number}", response_model=Acknowledgement, summary="Update Acknowledgement", description="Modifies the details of an existing acknowledgement, such as confirmed dates or quantities.", tags=["AR - Acknowledgements"])
async def update_acknowledgement(ack_number: str, ack_update: AcknowledgementUpdate):
    """
    Update an Acknowledgement.
    """
    # Lógica para actualizar un acknowledgement
    raise HTTPException(status_code=404, detail=f"Acknowledgement {ack_number} not found")

@router.delete("/acknowledgements/{ack_number}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete Acknowledgement", description="Removes an acknowledgement record from the system based on its unique acknowledgement number.", tags=["AR - Acknowledgements"])
async def delete_acknowledgement(ack_number: str):
    """
    Delete an Acknowledgement.
    """
    # Lógica para eliminar un acknowledgement
    print(f"Deleting Acknowledgement: {ack_number}")
    return
