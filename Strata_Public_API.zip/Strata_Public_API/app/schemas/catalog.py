from pydantic import BaseModel, Field
from typing import Optional

class CatalogItem(BaseModel):
    catalogCode: str = Field(..., description="Unique code for the catalog item")
    productNumber: str = Field(..., description="The product number this catalog item refers to")
    description: str = Field(..., description="Description of the catalog item")
    manufacturer: Optional[str] = None
    listPrice: float = Field(..., description="The public list price of the item")
    costPrice: Optional[float] = Field(None, description="The cost price for the dealer")
    category: Optional[str] = None

class CatalogItemUpdate(BaseModel):
    productNumber: Optional[str] = None
    description: Optional[str] = None
    manufacturer: Optional[str] = None
    listPrice: Optional[float] = None
    costPrice: Optional[float] = None
    category: Optional[str] = None