from pydantic import BaseModel, Field, EmailStr
from typing import Optional, Literal
from datetime import datetime

class User(BaseModel):
    userId: str = Field(..., description="Unique identifier for the user")
    name: str
    lastName: str
    email: EmailStr
    phone: Optional[str] = None
    userType: Literal["Client", "Avanto Employee"]
    status: Literal["Active", "Inactive"] = "Active"
    createdAt: datetime = Field(default_factory=datetime.utcnow, description="Timestamp when the user was created")

class UserUpdate(BaseModel):
    name: Optional[str] = None
    lastName: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    userType: Optional[Literal["Client", "Avanto Employee"]] = None
    status: Optional[Literal["Active", "Inactive"]] = None