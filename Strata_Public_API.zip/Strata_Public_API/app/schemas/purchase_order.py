from pydantic import BaseModel, Field
from typing import List, Optional, Literal

class POInfo(BaseModel):
    poNumber: str = Field(..., description="Unique identifier for purchase order")
    poDate: str = Field(..., description="Date when PO was created", format="date")
    expectedDeliveryDate: Optional[str] = Field(None, description="Anticipated date of delivery", format="date")
    paymentTerms: Optional[str] = Field(None, description="Terms of payment for the order")
    orderStatus: Literal["Draft", "Submitted", "Approved", "In Process", "Delivered", "Completed", "Cancelled"] = Field(..., description="Current status of the purchase order")

class Vendor(BaseModel):
    name: str = Field(..., description="Name of the supplier")
    address: Optional[str] = Field(None, description="Physical address of vendor")
    contactAssociated: Optional[str] = Field(None, description="Primary contact at vendor")
    email: Optional[str] = Field(None, description="Email contact for vendor", format="email")
    phone: Optional[str] = Field(None, description="Phone number for vendor")

class Shipping(BaseModel):
    shipToAddress: str = Field(..., description="Delivery location address")
    shippingTerms: Optional[str] = Field(None, description="Terms for shipping arrangements")
    shippingRequirements: Optional[dict] = Field(None, description="Special shipping instructions")
    freightTerms: Optional[Literal["FOB Origin", "FOB Destination", "CIF", "Prepaid", "Collect"]] = Field(None, description="Who pays for freight and how")

class LineItemTags(BaseModel):
    tag1: Optional[str] = None
    tag2: Optional[str] = None
    tag3: Optional[str] = None
    tag4: Optional[str] = None
    tag5: Optional[str] = None

class LineItem(BaseModel):
    productNumber: str = Field(..., description="Unique identifier for the product")
    quantity: float = Field(..., description="Number of units ordered")
    productCost: float = Field(..., description="Cost of the product to dealer")
    catalogCode: Optional[str] = Field(None, description="Reference code from product catalog")
    manufacturerCode: Optional[str] = Field(None, description="Code identifying the manufacturer")
    optionDescription: Optional[str] = Field(None, description="Description of selected options")
    optionGroup: Optional[str] = Field(None, description="Category grouping for options")
    optionNumber: Optional[str] = Field(None, description="Identifier for specific option")
    productDescription: Optional[str] = Field(None, description="Detailed description of the product")
    productList: Optional[float] = Field(None, description="List price of the product")
    productSell: Optional[float] = Field(None, description="Selling price of the product")
    purchaseDiscount: Optional[float] = Field(None, description="Discount on purchase price as percentage")
    sellDiscount: Optional[float] = Field(None, description="Discount on selling price as percentage")
    tags: Optional[LineItemTags] = None
    totalList: Optional[float] = Field(None, description="Total list price for line item")
    totalProduct: Optional[float] = Field(None, description="Total product cost for line item")
    totalPurchase: Optional[float] = Field(None, description="Total purchase amount for line item")
    totalSell: Optional[float] = Field(None, description="Total selling amount for line item")
    dimensions: Optional[str] = Field(None, description="Size specifications of furniture")
    furnitureCategory: Optional[Literal["Seating", "Storage", "Tables", "Desks", "Accessories", "Other"]] = Field(None, description="Type of furniture")
    assemblyRequired: Optional[bool] = Field(None, description="Whether assembly is needed")
    warrantyInformation: Optional[str] = Field(None, description="Details about product warranty")

class Project(BaseModel):
    projectName: Optional[str] = Field(None, description="Name of associated project")
    projectManager: Optional[str] = Field(None, description="Person managing the project")
    projectStatus: Optional[Literal["Planning", "In Progress", "On Hold", "Completed", "Cancelled"]] = Field(None, description="Current status of the project")
    installationDate: Optional[str] = Field(None, description="When furniture will be installed", format="date")

class Financials(BaseModel):
    poTotalAmount: Optional[float] = Field(None, description="Total value of purchase order")
    discountAmount: Optional[float] = Field(None, description="Any discounts applied")
    taxAmount: Optional[float] = Field(None, description="Taxes applied to the order")
    invoiceStatus: Optional[Literal["Not Invoiced", "Partially Invoiced", "Fully Invoiced", "Paid"]] = Field(None, description="Current status of invoicing")
    remainingPoAmount: Optional[float] = Field(None, description="Amount still to be paid")

class Metadata(BaseModel):
    createdAt: Optional[str] = Field(None, description="Timestamp when PO was created", format="date-time")
    updatedAt: Optional[str] = Field(None, description="Timestamp when PO was last updated", format="date-time")
    createdBy: Optional[str] = Field(None, description="User who created the PO")
    updatedBy: Optional[str] = Field(None, description="User who last updated the PO")

class PurchaseOrder(BaseModel):
    poInfo: POInfo
    vendor: Vendor
    lineItems: List[LineItem]
    shipping: Optional[Shipping] = None
    project: Optional[Project] = None
    financials: Optional[Financials] = None
    complianceCertifications: Optional[List[str]] = Field(None, description="Industry standard certifications")
    metadata: Optional[Metadata] = None

class PurchaseOrderUpdate(BaseModel):
    poInfo: Optional[POInfo] = None
    vendor: Optional[Vendor] = None
    lineItems: Optional[List[LineItem]] = None
    shipping: Optional[Shipping] = None
    project: Optional[Project] = None
    financials: Optional[Financials] = None
    complianceCertifications: Optional[List[str]] = None
    metadata: Optional[Metadata] = None
