from pydantic import BaseModel, Field
from typing import Optional
from datetime import date

class OperatingBillInfo(BaseModel):
    billNumber: str = Field(..., description="Unique identifier for the operating bill")
    billDate: date
    dueDate: Optional[date] = None
    totalAmount: float = Field(..., description="Total amount of the bill")
    category: str = Field(..., description="Expense category, e.g., 'Rent', 'Utilities', 'Office Supplies'")

class OperatingBillVendor(BaseModel):
    vendorName: str
    vendorId: Optional[str] = None

class OperatingBill(BaseModel):
    info: OperatingBillInfo
    vendor: OperatingBillVendor
    description: Optional[str] = "General operating expense"

class OperatingBillUpdate(BaseModel):
    info: Optional[OperatingBillInfo] = None
    vendor: Optional[OperatingBillVendor] = None
    description: Optional[str] = None