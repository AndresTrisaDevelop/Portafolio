# SIF File Validator

A web-based utility built with Flask and vanilla JavaScript to validate, parse, and preview SIF (Standard Interchange Format) files. This tool is designed to help users ensure their SIF files are well-formed and contain all required data before processing.

## What is a SIF file?

A **SIF (Standard Interchange Format)** file is a simple, text-based data file used to exchange product and order information. It follows a straightforward `KEY=VALUE` structure where each line contains a specific piece of data.

The keys (e.g., `PN`, `QT`, `PL`) are standardized identifiers representing data fields like "Product Number," "Line Item Quantity," and "Product List Price." This format allows different software systems, common in manufacturing and sales industries, to exchange order data reliably.

## Features

*   **Transaction Data Entry**: A comprehensive form to input header information like customer, order, shipping, and billing details.
*   **File Upload**: Simple drag-and-drop or file selection for `.sif` files.
*   **Comprehensive Validation**: Checks uploaded files and form data against a master list of codes (`sif_codes.json`) and reports on:
    *   **Missing Required Codes**: Identifies mandatory codes that are not present.
    *   **Unrecognized Codes**: Flags any codes found in the file that are not in the master list.
    *   **Recognized Codes**: Lists all valid codes found in the file.
*   **Line Item Parsing**: Intelligently parses the SIF file to identify and display individual line items in a clean, tabular format.
*   **File Preview**: View the raw text content of your uploaded `.sif` file.
*   **JSON Preview**: See a structured JSON representation of the parsed line items, with human-readable keys.
*   **Searchable Code Dictionary**: A "Supported Codes" tab that lists all valid SIF codes and their descriptions, with a real-time search filter.

## Technology Stack

*   **Backend**: Python, Flask
*   **Frontend**: HTML5, CSS3, Vanilla JavaScript
*   **Data Format**: JSON (for SIF code definitions)

## File Structure

```
.
├── app.py                  # Main Flask application logic
├── README.md               # This file
├── static/
│   ├── sif_codes.json      # Data file defining all valid SIF codes and their properties
│   └── style.css           # All styles for the application
└── templates/
    └── index.html          # Single-page HTML template for the UI
```

## How It Works

1.  **Data Definition**: The `static/sif_codes.json` file acts as the single source of truth, defining every valid SIF code, its description, and whether it's required.
2.  **User Interaction**: The user fills in the transaction form and uploads a `.sif` file via the UI in `index.html`.
3.  **Backend Processing**: The `/upload` endpoint in `app.py` receives the form data and the file.
    *   It reads the SIF code definitions from the JSON file.
    *   It parses the uploaded `.sif` file line by line, splitting each line at the `=` to get the code and value.
    *   It combines the codes from the form and the file into a single set of "found codes."
    *   It compares this set against the "required codes" and "all valid codes" to find discrepancies.
    *   It identifies line items (demarcated by the `PN` code) and organizes them into a list of dictionaries.
4.  **Response and Rendering**:
    *   The backend returns a single JSON object containing all validation results, parsed line items, and other relevant data.
    *   The frontend JavaScript catches this response and dynamically populates the "Validation Results," "File Preview," "JSON Preview," and line item table without a page reload.

## How to Run the Application

1.  **Prerequisites**:
    *   Python 3.x
    *   `pip` (Python package installer)

2.  **Clone the repository**:
    ```bash
    git clone <your-repository-url>
    cd <repository-directory>
    ```

3.  **Create a virtual environment (recommended)**:
    ```bash
    # For Windows
    python -m venv venv
    .\venv\Scripts\activate

    # For macOS/Linux
    python3 -m venv venv
    source venv/bin/activate
    ```

4.  **Install dependencies**:
    ```bash
    pip install Flask
    ```

5.  **Run the Flask app**:
    ```bash
    python app.py
    ```

6.  **Access the application**:
    Open your web browser and navigate to `http://127.0.0.1:5000`.