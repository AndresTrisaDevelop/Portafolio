import json
import os
from flask import Flask, request, render_template, jsonify, send_from_directory

app = Flask(__name__)

# Configuration
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def load_sif_codes():
    """Loads all and required SIF codes from the JSON file."""
    try:
        with open(os.path.join('static', 'sif_codes.json'), 'r') as f:
            sif_data = json.load(f)
            all_codes = {item['SIF Identifier'] for item in sif_data if item.get('SIF Identifier')}
            required_codes = {item['SIF Identifier'] for item in sif_data if item.get('Required') == 'Yes'}
            # Create a mapping from SIF Identifier to Data Description
            code_map = {item['SIF Identifier']: item['Data Description'] for item in sif_data if item.get('SIF Identifier')}
            return all_codes, required_codes, code_map
    except (FileNotFoundError, json.JSONDecodeError):
        return set(), set(), {}

@app.route('/')
def index():
    """Renders the main upload page."""
    return render_template('index.html')

@app.route('/supported-codes')
def get_supported_codes():
    """Serves the list of supported SIF codes from the JSON file."""
    return send_from_directory('static', 'sif_codes.json')


@app.route('/upload', methods=['POST'])
def upload_file():
    """Handles file upload and validation."""
    if 'sifFile' not in request.files:
        return jsonify({'error': 'No file part in the request'}), 400
    
    file = request.files['sifFile']

    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    if file and file.filename.lower().endswith('.sif'):
        try:
            all_valid_codes, required_codes, code_map = load_sif_codes()
            if not all_valid_codes:
                 return jsonify({'error': 'Could not load SIF codes definition file.'}), 500

            # --- New: Get transaction data from the form ---
            transaction_data = {
                'SF': request.form.get('SF'),
                'PT': request.form.get('PT'),
                'TL': request.form.get('TL'),
                'TP': request.form.get('TP'),
                'ORDNUM': request.form.get('ORDNUM'),
                'CUSTNAME': request.form.get('CUSTNAME'),
                'SHIPTO_NAME': request.form.get('SHIPTO_NAME'),
                'SHIPTO_ADDR1': request.form.get('SHIPTO_ADDR1'),
                'SHIPTO_ADDR2': request.form.get('SHIPTO_ADDR2'),
                'SHIPTO_CITY': request.form.get('SHIPTO_CITY'),
                'SHIPTO_STATE': request.form.get('SHIPTO_STATE'),
                'SHIPTO_ZIP': request.form.get('SHIPTO_ZIP'),
                'BILLTO_NAME': request.form.get('BILLTO_NAME'),
                'BILLTO_ADDR1': request.form.get('BILLTO_ADDR1'),
                'BILLTO_CITY': request.form.get('BILLTO_CITY'),
                'BILLTO_STATE': request.form.get('BILLTO_STATE'),
                'BILLTO_ZIP': request.form.get('BILLTO_ZIP'),
                'VR': request.form.get('VR'),
                'DT': request.form.get('DT'),
                'SL': request.form.get('SL'),
            }

            content = file.read().decode('utf-8')
            lines = content.splitlines()
            
            found_codes_set = set()
            line_items = []
            all_item_codes = set()
            current_item = None

            # --- New: Add form data to found_codes_set if present ---
            for code, value in transaction_data.items():
                if value: # Only add if the user provided a value
                    found_codes_set.add(code)

            for line in lines: # Using the '=' split logic we previously established
                parts = line.split('=', 1)
                if len(parts) == 2:
                    code = parts[0].strip()
                    value = parts[1].strip()
                    
                    if not code: continue

                    # --- New: Skip codes that were provided in the form to avoid duplication ---
                    # The file's value will be ignored in favor of the form's value.
                    if code in transaction_data and transaction_data[code]:
                        continue

                    found_codes_set.add(code)

                    # Only process codes that are valid for the line item grid
                    if code in all_valid_codes:
                        # Assume 'PN' starts a new line item
                        if code == 'PN':
                            if current_item is not None:
                                line_items.append(current_item)
                            current_item = {'PN': value}
                            all_item_codes.add('PN')
                        elif current_item is not None:
                            # If the code is an option, append it to group them in the grid view
                            if code in ['ON', 'OD', 'OG']:
                                # If the key already exists, append with a separator
                                if code in current_item:
                                    current_item[code] += f" | {value}"
                                else: # Otherwise, just add it
                                    current_item[code] = value
                            else:
                                current_item[code] = value
                            all_item_codes.add(code)
            
            if current_item is not None:
                line_items.append(current_item)
            
            # Create a JSON-friendly version of line items with full descriptions as keys
            json_preview = []
            for item in line_items:
                new_item = {}
                for code, value in item.items():
                    # Use the description from code_map as the new key, fallback to the code itself if not found
                    new_key = code_map.get(code, code)
                    new_item[new_key] = value
                json_preview.append(new_item)

            # 1. Find codes in the file that are not in our master list
            unrecognized_codes = sorted(list(found_codes_set - all_valid_codes))
            # 2. Find recognized codes that ARE in the file
            recognized_codes = sorted(list(found_codes_set.intersection(all_valid_codes)))
            # 3. Find required codes that are NOT in the file
            missing_required_codes = sorted(list(required_codes - found_codes_set))

            # --- New: Add transaction data to the results ---
            # This will be displayed in the UI.
            header_data_from_file_and_form = {
                code: value for code, value in transaction_data.items() if value
            }
            for code in recognized_codes:
                if code not in all_item_codes and code not in header_data_from_file_and_form:
                    header_data_from_file_and_form[code] = "Value from file" # Placeholder, as we don't store header values yet

            # Create headers based on the codes actually found in the line items
            ordered_headers = sorted(list(all_item_codes), key=lambda x: list(code_map.keys()).index(x) if x in code_map else 999)

            return jsonify({
                'unrecognized_codes': unrecognized_codes, 
                'missing_required_codes': missing_required_codes, 
                'recognized_codes': recognized_codes,
                'line_items': line_items,
                'line_item_headers': ordered_headers, # e.g., ['PN', 'PD', 'QT']
                'code_map': code_map, # e.g., {'PN': 'Product Number', ...}
                'json_preview': json_preview,
                'header_data': header_data_from_file_and_form
            })

        except Exception as e:
            return jsonify({'error': f'An error occurred while processing the file: {e}'}), 500

    return jsonify({'error': 'Invalid file type. Please upload a .sif file.'}), 400

if __name__ == '__main__':
    app.run(debug=True)