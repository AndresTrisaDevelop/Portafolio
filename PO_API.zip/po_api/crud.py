from typing import Dict, List, Optional
from .models import PurchaseOrder, PurchaseOrderUpdate, Metadata, LineItem
from datetime import datetime
from pydantic import BaseModel

# In-memory "database"
db: Dict[str, PurchaseOrder] = {}

def create_po(po: PurchaseOrder) -> PurchaseOrder:
    """Creates a new Purchase Order."""
    po_number = po.poInfo.poNumber
    if po_number in db:
        raise ValueError(f"Purchase Order with number {po_number} already exists.")
    
    # Set creation timestamp
    if po.metadata is None:
        po.metadata = Metadata()
    po.metadata.createdAt = po.metadata.createdAt or datetime.utcnow()
    po.metadata.updatedAt = datetime.utcnow()

    db[po_number] = po
    return po

def get_po(po_number: str) -> Optional[PurchaseOrder]:
    """Retrieves a Purchase Order by its number."""
    return db.get(po_number)

def get_all_pos() -> List[PurchaseOrder]:
    """Retrieves all Purchase Orders."""
    return list(db.values())

def update_po(po_number: str, po_update: PurchaseOrderUpdate) -> Optional[PurchaseOrder]:
    """Updates an existing Purchase Order."""
    if po_number not in db:
        return None
    
    stored_po = db[po_number]
    update_data = po_update.dict(exclude_unset=True) # Get only the fields that were provided

    # Recursively update nested Pydantic models
    for key, value in update_data.items():
        if isinstance(getattr(stored_po, key), BaseModel) and isinstance(value, dict):
            # It's a nested Pydantic model, update its fields
            current_nested_obj = getattr(stored_po, key)
            if current_nested_obj:
                # Update existing nested object
                updated_nested_obj = current_nested_obj.copy(update=value)
                setattr(stored_po, key, updated_nested_obj)
        else:
            # It's a simple field or a list
            setattr(stored_po, key, value)

    stored_po.metadata.updatedAt = datetime.utcnow()
    return stored_po

def delete_po(po_number: str) -> Optional[PurchaseOrder]:
    """Deletes a Purchase Order."""
    return db.pop(po_number, None)

def get_line_items(po_number: str) -> Optional[List[LineItem]]:
    """Retrieves all line items for a specific Purchase Order."""
    po = get_po(po_number)
    if po:
        return po.lineItems
    return None

def update_line_items(po_number: str, items: List[LineItem]) -> Optional[PurchaseOrder]:
    """Replaces all line items for a specific Purchase Order."""
    po = get_po(po_number)
    if po:
        po.lineItems = items
        po.metadata.updatedAt = datetime.utcnow()
        return po
    return None

def delete_line_items(po_number: str) -> Optional[PurchaseOrder]:
    """Deletes all line items from a specific Purchase Order."""
    po = get_po(po_number)
    if po:
        po.lineItems = []
        po.metadata.updatedAt = datetime.utcnow()
        return po
    return None