from fastapi import FastAPI, HTTPException, status
from typing import List
from . import crud, models

app = FastAPI(
    title="Purchase Order API",
    description="API for managing Purchase Orders",
    version="1.0.0",
)

@app.post("/pos/", response_model=models.PurchaseOrder, status_code=status.HTTP_201_CREATED, tags=["Create PO"])
def create_purchase_order(po: models.PurchaseOrder):
    """
    Create a new Purchase Order.
    The `poNumber` must be unique.
    """
    try:
        return crud.create_po(po)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))

@app.get("/pos/", response_model=List[models.PurchaseOrder], tags=["Read POs"])
def read_all_purchase_orders():
    """
    Retrieve all Purchase Orders.
    """
    return crud.get_all_pos()

@app.get("/pos/{po_number}", response_model=models.PurchaseOrder, tags=["Read POs"])
def read_purchase_order(po_number: str):
    """
    Retrieve a single Purchase Order by its `poNumber`.
    """
    db_po = crud.get_po(po_number)
    if db_po is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Purchase Order not found")
    return db_po

@app.put("/pos/{po_number}", response_model=models.PurchaseOrder, tags=["Update PO"])
def update_purchase_order(po_number: str, po_update: models.PurchaseOrderUpdate):
    """
    Update an existing Purchase Order.
    """
    updated_po = crud.update_po(po_number, po_update)
    if updated_po is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Purchase Order not found")
    return updated_po

@app.delete("/pos/{po_number}", status_code=status.HTTP_204_NO_CONTENT, tags=["Delete PO"])
def delete_purchase_order(po_number: str):
    """
    Delete a Purchase Order by its `poNumber`.
    """
    deleted_po = crud.delete_po(po_number)
    if deleted_po is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Purchase Order not found")
    return

# --- Line Item Endpoints ---

@app.get("/pos/{po_number}/items/", response_model=List[models.LineItem], tags=["Line Items"])
def read_line_items(po_number: str):
    """
    Retrieve all line items for a specific Purchase Order.
    """
    items = crud.get_line_items(po_number)
    if items is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Purchase Order not found")
    return items

@app.put("/pos/{po_number}/items/", response_model=models.PurchaseOrder, tags=["Line Items"])
def update_line_items(po_number: str, items: List[models.LineItem]):
    """
    Replace all line items for a specific Purchase Order.
    """
    updated_po = crud.update_line_items(po_number, items)
    if updated_po is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Purchase Order not found")
    return updated_po

@app.delete("/pos/{po_number}/items/", response_model=models.PurchaseOrder, tags=["Line Items"])
def delete_line_items(po_number: str):
    """
    Delete all line items from a specific Purchase Order.
    The PO will remain with an empty list of line items.
    """
    updated_po = crud.delete_line_items(po_number)
    if updated_po is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Purchase Order not found")
    return updated_po