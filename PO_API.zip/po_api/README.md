# Purchase Order API

This is a simple and fast API for managing Purchase Orders, built with Python and [FastAPI](https://fastapi.tiangolo.com/).

## Features

*   **CRUD Operations for Purchase Orders**: Create, Read, Update, and Delete purchase orders.
*   **Line Item Management**:
    *   Get, replace, or delete all line items for a specific PO.
*   **In-Memory Storage**: Uses a simple in-memory dictionary for data storage, making it easy to run and test without a database setup.
*   **Automatic API Documentation**: Interactive API documentation provided by Swagger UI and ReDoc.

## Project Structure

```
po_api/
├── __init__.py
├── crud.py           # Contains the business logic for data manipulation.
├── main.py           # The main FastAPI application file with all the endpoints.
├── models.py         # Pydantic models for data validation and serialization.
├── POs.json          # JSON Schema representation of the Purchase Order model.
└── README.md         # This file.
```

## Prerequisites

*   Python 3.8+
*   pip

## Setup and Installation

1.  **Clone the repository (or set up your project folder):**
    If this were a git repository, you would clone it. For now, just navigate to your project directory.

2.  **Create and activate a virtual environment (recommended):**

    ```bash
    # For Windows
    python -m venv venv
    .\venv\Scripts\activate

    # For macOS/Linux
    python3 -m venv venv
    source venv/bin/activate
    ```

3.  **Install the required dependencies:**
    Create a `requirements.txt` file with the following content:

    ```txt
    fastapi
    uvicorn[standard]
    ```

    Then, run the installation command:

    ```bash
    pip install -r requirements.txt
    ```

## How to Run the Application

1.  From the root directory (`c:\Users\RPC\OneDrive - UNIR\`), run the following command:

    ```bash
    uvicorn po_api.main:app --reload
    ```

2.  The API will be running at `http://127.0.0.1:8000`.

## API Documentation

Once the application is running, you can access the interactive API documentation in your browser:

*   **Swagger UI**: http://127.0.0.1:8000/docs
*   **ReDoc**: http://127.0.0.1:8000/redoc

These interfaces allow you to explore and test all the API endpoints directly.