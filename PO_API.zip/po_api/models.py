from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Literal
from datetime import date, datetime

# Enums from the schema
OrderStatus = Literal["Draft", "Submitted", "Approved", "In Process", "Delivered", "Completed", "Cancelled"]
FreightTerms = Literal["FOB Origin", "FOB Destination", "CIF", "Prepaid", "Collect"]
FurnitureCategory = Literal["Seating", "Storage", "Tables", "Desks", "Accessories", "Other"]
ProjectStatus = Literal["Planning", "In Progress", "On Hold", "Completed", "Cancelled"]
InvoiceStatus = Literal["Not Invoiced", "Partially Invoiced", "Fully Invoiced", "Paid"]

class PoInfo(BaseModel):
    """Core Purchase Order Information"""
    poNumber: str = Field(..., description="Unique identifier for purchase order")
    poDate: date = Field(..., description="Date when PO was created")
    expectedDeliveryDate: Optional[date] = Field(None, description="Anticipated date of delivery")
    paymentTerms: Optional[str] = Field(None, description="Terms of payment for the order")
    orderStatus: OrderStatus = Field(..., description="Current status of the purchase order")

class Vendor(BaseModel):
    """Vendor Information"""
    name: str = Field(..., description="Name of the supplier")
    address: Optional[str] = Field(None, description="Physical address of vendor")
    contactAssociated: Optional[str] = Field(None, description="Primary contact at vendor")
    email: Optional[EmailStr] = Field(None, description="Email contact for vendor")
    phone: Optional[str] = Field(None, description="Phone number for vendor")

class Shipping(BaseModel):
    """Shipping Information"""
    shipToAddress: str = Field(..., description="Delivery location address")
    shippingTerms: Optional[str] = Field(None, description="Terms for shipping arrangements")
    shippingRequirements: Optional[dict] = Field(None, description="Special shipping instructions")
    freightTerms: Optional[FreightTerms] = Field(None, description="Who pays for freight and how")

class Tags(BaseModel):
    tag1: Optional[str] = None
    tag2: Optional[str] = None
    tag3: Optional[str] = None
    tag4: Optional[str] = None
    tag5: Optional[str] = None

class LineItem(BaseModel):
    """Product being ordered"""
    catalogCode: Optional[str] = Field(None, description="Reference code from product catalog")
    quantity: float = Field(..., description="Number of units ordered")
    manufacturerCode: Optional[str] = Field(None, description="Code identifying the manufacturer")
    optionDescription: Optional[str] = Field(None, description="Description of selected options")
    optionGroup: Optional[str] = Field(None, description="Category grouping for options")
    optionNumber: Optional[str] = Field(None, description="Identifier for specific option")
    productCost: float = Field(..., description="Cost of the product to dealer")
    productDescription: Optional[str] = Field(None, description="Detailed description of the product")
    productList: Optional[float] = Field(None, description="List price of the product")
    productNumber: str = Field(..., description="Unique identifier for the product")
    productSell: Optional[float] = Field(None, description="Selling price of the product")
    purchaseDiscount: Optional[float] = Field(None, description="Discount on purchase price as percentage")
    sellDiscount: Optional[float] = Field(None, description="Discount on selling price as percentage")
    tags: Optional[Tags] = None
    totalList: Optional[float] = Field(None, description="Total list price for line item")
    totalProduct: Optional[float] = Field(None, description="Total product cost for line item")
    totalPurchase: Optional[float] = Field(None, description="Total purchase amount for line item")
    totalSell: Optional[float] = Field(None, description="Total selling amount for line item")
    dimensions: Optional[str] = Field(None, description="Size specifications of furniture")
    furnitureCategory: Optional[FurnitureCategory] = Field(None, description="Type of furniture")
    assemblyRequired: Optional[bool] = Field(None, description="Whether assembly is needed")
    warrantyInformation: Optional[str] = Field(None, description="Details about product warranty")

class Project(BaseModel):
    """Project Information"""
    projectName: Optional[str] = Field(None, description="Name of associated project")
    projectManager: Optional[str] = Field(None, description="Person managing the project")
    projectStatus: Optional[ProjectStatus] = Field(None, description="Current status of the project")
    installationDate: Optional[date] = Field(None, description="When furniture will be installed")

class Financials(BaseModel):
    """Financial Information"""
    poTotalAmount: Optional[float] = Field(None, description="Total value of purchase order")
    discountAmount: Optional[float] = Field(None, description="Any discounts applied")
    taxAmount: Optional[float] = Field(None, description="Taxes applied to the order")
    invoiceStatus: Optional[InvoiceStatus] = Field(None, description="Current status of invoicing")
    remainingPoAmount: Optional[float] = Field(None, description="Amount still to be paid")

class Metadata(BaseModel):
    """Additional PO metadata"""
    createdAt: Optional[datetime] = Field(None, description="Timestamp when PO was created")
    updatedAt: Optional[datetime] = Field(None, description="Timestamp when PO was last updated")
    createdBy: Optional[str] = Field(None, description="User who created the PO")
    updatedBy: Optional[str] = Field(None, description="User who last updated the PO")


class PurchaseOrder(BaseModel):
    """Purchase Order"""
    poInfo: PoInfo
    vendor: Vendor
    lineItems: List[LineItem]
    shipping: Optional[Shipping] = None
    project: Optional[Project] = None
    financials: Optional[Financials] = None
    complianceCertifications: Optional[List[str]] = Field(None, description="Industry standard certifications")
    metadata: Optional[Metadata] = None

    class Config:
        schema_extra = {
            "example": {
                "poInfo": {
                    "poNumber": "PO12345",
                    "poDate": "2023-10-27",
                    "orderStatus": "Submitted"
                },
                "vendor": {
                    "name": "Awesome Furniture Co."
                },
                "shipping": {
                    "shipToAddress": "123 Main St, Anytown, USA"
                },
                "lineItems": [
                    {
                        "productNumber": "CHR-001",
                        "quantity": 10,
                        "productCost": 150.00,
                        "productDescription": "Ergonomic Office Chair"
                    }
                ]
            }
        }

class PurchaseOrderUpdate(BaseModel):
    """Model for updating a Purchase Order. All fields are optional."""
    poInfo: Optional[PoInfo] = None
    vendor: Optional[Vendor] = None
    lineItems: Optional[List[LineItem]] = None
    shipping: Optional[Shipping] = None
    project: Optional[Project] = None
    financials: Optional[Financials] = None
    complianceCertifications: Optional[List[str]] = None
    metadata: Optional[Metadata] = None