import os
import pytesseract
import re
import logging
from pdf2image import convert_from_path
from pdf2image.exceptions import PDFInfoNotInstalledError, PDFPageCountError

# --- Setup structured logging ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Configuration --- Reader please read carefully ---
# Poppler is required for pdf2image to convert PDF pages to images.
# It's best practice to configure paths via environment variables
# In your terminal, before running the app, set the variable:
# > set POPPLER_PATH=C:\path\to\your\poppler\bin
POPPLER_PATH = os.getenv("POPPLER_PATH")

# --- !! IMPORTANT FALLBACK !! ---
# If you don't set the environment variable, uncomment and EDIT the line below.
# This provides a hardcoded path as a backup.
if not POPPLER_PATH:
    # **ACTION REQUIRED**: Replace this with the actual path to your Poppler 'bin' folder.
    POPPLER_PATH = r'C:\Program Files\poppler\Library\bin'
    
# --- Tesseract Configuration ---
# Uncomment the line below. The default path for the Tesseract installer is usually correct.
# Verify this path exists on your system.
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

def extract_text_from_pdf(pdf_path):
    """
    Converts a PDF to images and then uses OCR to extract text.
    Handles PDFs that don't have a text layer.
    """
    logging.info(f"Starting PDF processing for: {pdf_path}")
    try:
        # --- Pre-flight checks for external dependencies ---
        tesseract_path = pytesseract.pytesseract.tesseract_cmd
        if not tesseract_path or not os.path.isfile(tesseract_path):
            logging.error(f"Tesseract executable not found at the configured path: {tesseract_path}")
            return {"error": "Server-side configuration error: Tesseract path is not set correctly."}

        if not POPPLER_PATH or not os.path.isdir(POPPLER_PATH):
            logging.error("Poppler path is not configured correctly. Please edit ocr_processor.py or set the POPPLER_PATH environment variable.")
            # Return a specific error to show on the frontend
            return {"error": "Server-side configuration error: Poppler path is not set."}

        # Convert PDF to a list of PIL images
        images = convert_from_path(pdf_path, poppler_path=POPPLER_PATH)
        
        full_text = ""
        for i, image in enumerate(images):
            logging.info(f"  - OCR on page {i+1}...")
            # Use Tesseract to do OCR on the image
            text = pytesseract.image_to_string(image)
            full_text += text + "\n"
            
        return full_text
    except (PDFInfoNotInstalledError, PDFPageCountError):
        logging.error("Poppler processing error. Ensure Poppler is installed and the POPPLER_PATH is correct.")
        return {"error": "Server-side configuration error: Could not process PDF with Poppler."}
    except pytesseract.TesseractNotFoundError:
        logging.error("Tesseract not found. Ensure Tesseract is installed and the path in ocr_processor.py is correct.")
        return {"error": "Server-side configuration error: Tesseract executable not found."}
    except Exception as e:
        logging.error(f"An unexpected error occurred during PDF processing: {e}")
        return {"error": f"An unexpected server error occurred: {e}"}

def parse_po_data(text):
    """
    Parses the raw text to extract Purchase Order information using regex.
    This is a basic example and may need to be tailored to your specific PO format.
    """
    # Initialize the data structure according to the new schema
    data = {
        "poInfo": {"poNumber": None, "poDate": None, "expectedDeliveryDate": None, "paymentTerms": None, "orderStatus": "Submitted"},
        "vendor": {"name": None, "address": None, "contactAssociated": None, "email": None, "phone": None},
        "dealer": {"dealerId": None, "dealerName": None, "dealerAddress": None, "dealerContact": None, "dealerEmail": None, "dealerPhone": None, "dealerAccountNumber": None},
        "installation": {"installationDate": None, "installationAddress": None, "installationContact": None, "installationEmail": None, "installationPhone": None, "specialInstructions": None},
        "billing": {"billToName": None, "billToAddress": None, "billToContact": None, "billToEmail": None, "billToPhone": None, "currency": "USD"},
        "shipping": {"shipToAddress": None, "shippingTerms": None},
        "lineItems": {},
        "financials": {"poTotalAmount": None, "discountAmount": None, "taxAmount": None},
        "project": {"projectName": None},
        "metadata": {} # Can be populated with creation date etc. later
    }

    # --- General Information Regex ---
    po_number_pattern = re.compile(r'(?:Purchase Order|PO)\s?#?No\.?[:\s]*([A-Z0-9-]+)', re.IGNORECASE)
    date_pattern = re.compile(r'(?:Order\s)?Date[:\s]*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\w+\s\d{1,2},\s\d{4})', re.IGNORECASE)
    payment_terms_pattern = re.compile(r'Payment Terms[:\s]*(.*)', re.IGNORECASE)
    project_name_pattern = re.compile(r'Project Name[:\s]*(.*)', re.IGNORECASE)
    email_pattern = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
    phone_pattern = re.compile(r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}')

    # --- Financials Regex ---
    total_amount_pattern = re.compile(r'(?:Grand\sTotal|Total|Balance\sDue)\s*[:\s]*\$?([\d,]+\.\d{2})', re.IGNORECASE)
    tax_pattern = re.compile(r'Tax(?:\s*\(?@?[\d.]+\%\)?)?[:\s]*\$?([\d,]+\.\d{2})', re.IGNORECASE)
    discount_pattern = re.compile(r'Discount[:\s-]*\$?([\d,]+\.\d{2})', re.IGNORECASE)

    # --- Block Extraction Helper ---
    def get_text_block(text, start_keyword, end_keywords):
        """Extracts a block of text between a start keyword and a list of possible end keywords."""
        try:
            start_regex = re.compile(start_keyword, re.IGNORECASE)
            start_match = start_regex.search(text)
            if not start_match:
                return None, None
            
            start_index = start_match.end()
            end_index = len(text)

            # Find the earliest occurrence of any end keyword after the start
            for end_keyword in end_keywords:
                end_regex = re.compile(end_keyword, re.IGNORECASE)
                end_match = end_regex.search(text, start_index)
                if end_match and end_match.start() < end_index:
                    end_index = end_match.start()
            
            return text[start_index:end_index].strip(), text[end_index:]
        except Exception:
            return None, None

    # --- Parsing Logic ---

    # 1. Parse top-level info
    if match := po_number_pattern.search(text): data["poInfo"]["poNumber"] = match.group(1).strip()
    if match := date_pattern.search(text): data["poInfo"]["poDate"] = match.group(1).strip()
    if match := payment_terms_pattern.search(text): data["poInfo"]["paymentTerms"] = match.group(1).strip().split('\n')[0]
    if match := project_name_pattern.search(text): data["project"]["projectName"] = match.group(1).strip().split('\n')[0]

    # 2. Parse blocks (Vendor, Bill To, Ship To)
    # The order of end_keywords is important to correctly segment the document
    end_markers = [r'\bShip\sTo\b', r'\bBill\sTo\b', r'\bDescription\b', r'\bLine\sItems\b']
    vendor_block, remaining_text = get_text_block(text, r'\bVendor\b', end_markers)
    bill_to_block, remaining_text = get_text_block(remaining_text or text, r'\bBill\sTo\b', [r'\bShip\sTo\b', r'\bDescription\b'])
    ship_to_block, _ = get_text_block(remaining_text or text, r'\bShip\sTo\b', [r'\bDescription\b', r'\bLine\sItems\b'])

    if vendor_block:
        lines = vendor_block.split('\n')
        data["vendor"]["name"] = lines[0].strip()
        data["vendor"]["address"] = "\n".join(l.strip() for l in lines[1:] if l.strip())
        if match := email_pattern.search(vendor_block): data["vendor"]["email"] = match.group(0)
        if match := phone_pattern.search(vendor_block): data["vendor"]["phone"] = match.group(0)

    if bill_to_block:
        lines = bill_to_block.split('\n')
        data["billing"]["billToName"] = lines[0].strip()
        data["billing"]["billToAddress"] = "\n".join(l.strip() for l in lines[1:] if l.strip())

    if ship_to_block:
        data["shipping"]["shipToAddress"] = ship_to_block.strip()
        # If installation address is not specified, assume it's the shipping address
        if not data["installation"]["installationAddress"]:
            data["installation"]["installationAddress"] = ship_to_block.strip()

    # 3. Parse Financials
    all_totals = total_amount_pattern.findall(text)
    if all_totals:
        max_total = max([float(t.replace(',', '')) for t in all_totals])
        data["financials"]["poTotalAmount"] = max_total

    if match := tax_pattern.search(text):
        data["financials"]["taxAmount"] = float(match.group(1).replace(',', ''))

    if match := discount_pattern.search(text):
        data["financials"]["discountAmount"] = float(match.group(1).replace(',', ''))

    
    # This regex is designed to be more flexible. It looks for a line containing:
    # 1. (?P<productNumber>\S+): A product number (assumed to be a single word at the start).
    # 2. (?P<productDescription>.+?): A non-greedy description.
    # 3. (?P<quantity>\d+(?:\.\d+)?): A quantity (integer or decimal).
    # 4. (?P<unitPrice>[\d,]+\.\d{2}): A unit price in currency format.
    # 5. Line Item Extraction
    # It makes the total price at the end optional to increase matches.
    line_item_pattern = re.compile(
        r'^(?P<productNumber>\S+)\s+'
        r'(?P<productDescription>.+?)\s+'
        r'(?P<quantity>\d+(?:\.\d+)?)\s+'
        r'(?P<unitPrice>[\d,]+\.\d{2})'
        r'(?:\s+[\d,]+\.\d{2})?\s*$',  # Optional total price at the end
        re.MULTILINE | re.IGNORECASE
    )
    
    # Find the start of the line items table to avoid capturing header text
    # We look for a line that contains at least two of the common table headers.
    table_start_match = re.search(r'^(?=.*qty)(?=.*description).*$', text, re.IGNORECASE | re.MULTILINE)
    table_text = text[table_start_match.end():] if table_start_match else text

    item_counter = 1
    for match in line_item_pattern.finditer(table_text):
        try:
            item_data = match.groupdict()
            
            # Avoid capturing the grand total row as a line item
            if "total" in item_data.get("description", "").lower():
                continue
            
            item_key = f"item_{item_counter}"
            item_counter += 1
            data["lineItems"][item_key] = {
                "catalogCode": item_data.get("productNumber", "").strip() or None,
                "productNumber": item_data.get("productNumber", "").strip() or None,
                "quantity": float(item_data.get("quantity", 0)),
                "productDescription": item_data.get("productDescription", "").strip(),
                "productSell": float(item_data.get("unitPrice", "0").replace(',', '')), # Mapping unitPrice to productSell
                "totalSell": None, # This regex version prioritizes unit price
                # Other fields from schema are set to None as they are not captured by this regex
                "manufacturerCode": None,
                "productCost": None,
                "totalPurchase": None
                }
        except (ValueError, IndexError):
            continue

    return data

def process_purchase_order(pdf_path):
    """
    Main function to orchestrate the PDF processing and data extraction.
    Returns a dictionary.
    """
    raw_text = extract_text_from_pdf(pdf_path)

    # Check if extract_text_from_pdf returned an error dictionary
    if isinstance(raw_text, dict) and 'error' in raw_text:
        return raw_text # Pass the specific error message back to the frontend
    elif not raw_text:
        return {"error": "Could not extract text from PDF. Check logs for details."}

    extracted_data = parse_po_data(raw_text)
    
    return extracted_data