# Purchase Order (PO) OCR Extractor

This project is a web-based application built with Python and Flask that extracts structured data from Purchase Order (PO) PDF documents. It uses Tesseract for Optical Character Recognition (OCR) to handle scanned documents without a text layer and presents the extracted information in a user-friendly, multi-tab interface.

## Features

- **Web-Based UI**: A modern, responsive user interface built with Flask, HTML, and CSS.
- **PDF Upload & Preview**: Instantly preview uploaded PDF documents directly in the browser.
- **OCR Processing**: Utilizes `pytesseract` (a wrapper for Google's Tesseract) to extract text from image-based PDFs.
- **Structured Data Extraction**: Employs regular expressions to parse the raw OCR text and populate a structured JSON object.
- **Interactive JSON Viewer**: View, copy, download, and edit the extracted JSON data.
- **Dynamic Data Form**: An editable form is dynamically generated from the extracted data, allowing for user verification and correction.
- **Data Submission**: The final, verified data can be submitted to a backend endpoint.

## Project Structure

```
/
├── app.py                  # Main Flask application server
├── ocr_processor.py        # Core logic for PDF processing and OCR
├── requirements.txt        # Python dependencies
├── README.md               # This file
├── static/
│   └── style.css           # CSS for the frontend
├── templates/
│   └── index.html          # HTML template for the web UI
└── uploads/                # Temporary storage for uploaded PDFs (auto-created)
```

---

## Setup and Installation

Follow these steps to get the project running on your local machine.

### 1. Prerequisites (External Dependencies)

This project relies on two external programs that must be installed on your system.

#### Tesseract-OCR Engine
- **Purpose**: The core OCR engine that reads text from images.
- **Windows**:
  1. Download the installer from Tesseract at UB Mannheim.
  2. Run the installer. The default installation path is `C:\Program Files\Tesseract-OCR`, which is what the application expects. If you install it elsewhere, you must update the path in `ocr_processor.py`.
- **macOS**: `brew install tesseract`
- **Linux (Debian/Ubuntu)**: `sudo apt-get install tesseract-ocr`

#### Poppler
- **Purpose**: A PDF rendering library required by `pdf2image` to convert PDF pages into images.
- **Windows**:
  1. Download the latest binary `.zip` file from this Poppler for Windows blog.
  2. Extract the contents to a permanent location, for example, `C:\poppler`.
  3. The application expects the path to be `C:\Program Files\poppler\Library\bin`. You may need to move the extracted folder or update the `POPPLER_PATH` variable in `ocr_processor.py` to match your location.
- **macOS**: `brew install poppler`
- **Linux (Debian/Ubuntu)**: `sudo apt-get install poppler-utils`

### 2. Clone the Repository

```bash
git clone <your-repository-url>
cd OCR_Project
```

### 3. Set up a Python Virtual Environment

It is highly recommended to use a virtual environment to manage project dependencies.

```bash
# Create the virtual environment
python -m venv venv

# Activate it
# On Windows
.\venv\Scripts\activate
# On macOS/Linux
source venv/bin/activate
```

### 4. Install Python Libraries

Install all the required Python packages from the `requirements.txt` file.

```bash
pip install -r requirements.txt
```

---

## How to Run the Application

1.  **Verify Paths**: Before running, ensure the hardcoded paths for Tesseract and Poppler in `ocr_processor.py` match your installation locations.

2.  **Start the Flask Server**:
    Run the `app.py` file from your terminal.

    ```bash
    python app.py
    ```

3.  **Access the Application**:
    Open your web browser and navigate to the following URL:

    **http://127.0.0.1:5001**

You can now upload a PDF, preview it, and see the extracted data across the different tabs.
